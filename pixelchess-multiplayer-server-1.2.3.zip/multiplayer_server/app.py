"""HTTP room and move relay for Pixel Chess (Flask/WSGI compatible)."""

import json
import os
import secrets
import sqlite3
import string
import time

import chess
from flask import Flask, g, jsonify, request

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024
DB_PATH = os.environ.get('PIXEL_CHESS_DB', os.path.join(os.path.dirname(__file__), 'rooms.sqlite3'))
ROOM_TTL = 60 * 60 * 8
FLAGS = {'UA': '🇺🇦', 'US': '🇺🇸', 'GB': '🇬🇧', 'PL': '🇵🇱', 'DE': '🇩🇪',
         'FR': '🇫🇷', 'CA': '🇨🇦', 'JP': '🇯🇵', 'AU': '🇦🇺', 'BR': '🇧🇷',
         'IN': '🇮🇳', 'ES': '🇪🇸', 'IT': '🇮🇹', 'NL': '🇳🇱', 'SE': '🇸🇪',
         'NO': '🇳🇴', 'FI': '🇫🇮', 'TR': '🇹🇷', 'CZ': '🇨🇿', 'RO': '🇷🇴'}


def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA journal_mode=WAL')
        g.db.executescript('''
            CREATE TABLE IF NOT EXISTS rooms (
                code TEXT PRIMARY KEY, private INTEGER NOT NULL, description TEXT NOT NULL,
                host_name TEXT NOT NULL, host_country TEXT NOT NULL, host_token TEXT NOT NULL,
                host_device TEXT NOT NULL DEFAULT 'mobile',
                guest_name TEXT, guest_country TEXT, guest_token TEXT,
                guest_device TEXT NOT NULL DEFAULT 'mobile',
                status TEXT NOT NULL, fen TEXT NOT NULL, created REAL NOT NULL, touched REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL,
                kind TEXT NOT NULL, sender TEXT NOT NULL, payload TEXT NOT NULL, created REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS event_room_idx ON events(code, id);
            CREATE TABLE IF NOT EXISTS presence (
                code TEXT NOT NULL, color TEXT NOT NULL, x REAL NOT NULL, y REAL NOT NULL,
                drag_square INTEGER, visible INTEGER NOT NULL, updated REAL NOT NULL,
                PRIMARY KEY(code, color)
            );
        ''')
        columns = {row['name'] for row in g.db.execute('PRAGMA table_info(rooms)')}
        if 'host_device' not in columns:
            g.db.execute("ALTER TABLE rooms ADD COLUMN host_device TEXT NOT NULL DEFAULT 'mobile'")
        if 'guest_device' not in columns:
            g.db.execute("ALTER TABLE rooms ADD COLUMN guest_device TEXT NOT NULL DEFAULT 'mobile'")
        g.db.commit()
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    connection = g.pop('db', None)
    if connection is not None:
        connection.close()


def clean_expired(connection):
    cutoff = time.time() - ROOM_TTL
    connection.execute('DELETE FROM events WHERE code IN (SELECT code FROM rooms WHERE touched < ?)', (cutoff,))
    connection.execute('DELETE FROM presence WHERE code IN (SELECT code FROM rooms WHERE touched < ?)', (cutoff,))
    connection.execute('DELETE FROM rooms WHERE touched < ?', (cutoff,))


def fail(message, status=400):
    return jsonify(error=message), status


def valid_country(value):
    country = str(value or '').strip().upper()
    return country if len(country) == 2 and country.isalpha() and country not in {'UN', 'ZZ'} else 'ZZ'


def valid_device(value):
    return 'desktop' if str(value or '').lower() == 'desktop' else 'mobile'


@app.get('/api/health')
def health():
    return jsonify(ok=True, service='pixel-chess-multiplayer')


@app.get('/api/profile')
def profile():
    country = valid_country(request.headers.get('X-Detected-Country'))
    return jsonify(country=country, flag=FLAGS.get(country, ''))


@app.get('/api/rooms')
def list_rooms():
    connection = db()
    clean_expired(connection)
    rows = connection.execute('''SELECT code, description, host_name, host_country, host_device, created
                                 FROM rooms WHERE private=0 AND status='waiting'
                                 ORDER BY created DESC LIMIT 50''').fetchall()
    connection.commit()
    return jsonify(rooms=[{'code': r['code'], 'description': r['description'],
                           'host': r['host_name'], 'country': r['host_country'],
                           'device': r['host_device'],
                           'flag': FLAGS.get(r['host_country'], '')} for r in rows])


@app.post('/api/rooms')
def create_room():
    data = request.get_json(silent=True) or {}
    nickname = str(data.get('nickname', '')).strip()[:20]
    description = str(data.get('description', '')).strip()[:80]
    private = bool(data.get('private'))
    country = valid_country(data.get('country') or request.headers.get('X-Detected-Country'))
    device = valid_device(data.get('device'))
    if not nickname:
        return fail('Nickname is required')
    connection = db()
    clean_expired(connection)
    alphabet = string.ascii_uppercase + string.digits
    for _ in range(8):
        code = ''.join(secrets.choice(alphabet) for _ in range(6))
        token = secrets.token_urlsafe(32)
        try:
            now = time.time()
            connection.execute('''INSERT INTO rooms(code,private,description,host_name,host_country,
                host_token,host_device,status,fen,created,touched) VALUES(?,?,?,?,?,?,?,'waiting',?,?,?)''',
                (code, int(private), description, nickname, country, token, device,
                 chess.STARTING_FEN, now, now))
            connection.commit()
            return jsonify(code=code, token=token, color='white', country=country, device=device,
                           flag=FLAGS.get(country, ''), status='waiting', seq=0,
                           private=private, description=description)
        except sqlite3.IntegrityError:
            continue
    return fail('Could not allocate a room code', 503)


@app.post('/api/rooms/<code>/join')
def join_room(code):
    data = request.get_json(silent=True) or {}
    nickname = str(data.get('nickname', '')).strip()[:20]
    if not nickname:
        return fail('Nickname is required')
    connection = db()
    country = valid_country(data.get('country') or request.headers.get('X-Detected-Country'))
    device = valid_device(data.get('device'))
    now = time.time()
    with connection:
        clean_expired(connection)
        room = connection.execute('SELECT * FROM rooms WHERE code=?', (code.upper(),)).fetchone()
        if room is None:
            return fail('Room not found', 404)
        if room['status'] != 'waiting':
            return fail('Room is already full', 409)
        if room['host_name'] == nickname:
            return fail('Choose a different nickname from the host', 409)
        token = secrets.token_urlsafe(32)
        connection.execute('''UPDATE rooms SET guest_name=?,guest_country=?,guest_token=?,guest_device=?,status='ready',touched=?
                              WHERE code=? AND status='waiting' ''',
                           (nickname, country, token, device, now, code.upper()))
        if connection.execute('SELECT changes()').fetchone()[0] != 1:
            return fail('Room is already full', 409)
        connection.execute('INSERT INTO events(code,kind,sender,payload,created) VALUES(?,?,?,?,?)',
                           (code.upper(), 'joined', 'black', json.dumps({'name': nickname, 'country': country}), now))
    return jsonify(code=code.upper(), token=token, color='black', country=country, device=device,
                   flag=FLAGS.get(country, ''), status='ready', seq=0,
                   opponent=room['host_name'], opponent_country=room['host_country'],
                   opponent_device=room['host_device'],
                   description=room['description'], private=bool(room['private']))


def room_for_token(connection, code, token):
    room = connection.execute('SELECT * FROM rooms WHERE code=?', (code.upper(),)).fetchone()
    if room is None:
        return None, None
    if secrets.compare_digest(room['host_token'], token or ''):
        return room, 'white'
    if room['guest_token'] and secrets.compare_digest(room['guest_token'], token or ''):
        return room, 'black'
    return room, None


@app.get('/api/rooms/<code>/state')
def room_state(code):
    connection = db()
    auth = request.headers.get('Authorization', '')
    token = auth[7:] if auth.startswith('Bearer ') else ''
    room, color = room_for_token(connection, code, token)
    if room is None:
        return fail('Room not found', 404)
    if color is None:
        return fail('Invalid room token', 403)
    after = max(0, request.args.get('after', default=0, type=int))
    events = connection.execute('''SELECT id,kind,sender,payload FROM events
                                   WHERE code=? AND id>? ORDER BY id LIMIT 100''',
                                (code.upper(), after)).fetchall()
    with connection:
        connection.execute('UPDATE rooms SET touched=? WHERE code=?', (time.time(), code.upper()))
    opponent = room['guest_name'] if color == 'white' else room['host_name']
    opponent_country = room['guest_country'] if color == 'white' else room['host_country']
    opponent_device = room['guest_device'] if color == 'white' else room['host_device']
    row = connection.execute('SELECT x,y,drag_square,visible,updated FROM presence WHERE code=? AND color=?',
                             (code.upper(), 'black' if color == 'white' else 'white')).fetchone()
    presence_data = None
    if row:
        presence_data = {
            'x': row['x'], 'y': row['y'], 'drag_square': row['drag_square'],
            'visible': bool(row['visible'] and time.time() - row['updated'] < 2.0),
        }
    return jsonify(status=room['status'], fen=room['fen'], color=color,
                   opponent=opponent, opponent_country=opponent_country,
                   opponent_device=opponent_device, presence=presence_data,
                   opponent_flag=FLAGS.get(opponent_country or '', ''),
                   seq=events[-1]['id'] if events else after,
                   events=[{'id': event['id'], 'kind': event['kind'], 'sender': event['sender'],
                            'payload': json.loads(event['payload'])} for event in events])


@app.post('/api/rooms/<code>/presence')
def update_presence(code):
    data = request.get_json(silent=True) or {}
    connection = db()
    with connection:
        room, color = room_for_token(connection, code, str(data.get('token', '')))
        if room is None:
            return fail('Room not found', 404)
        if color is None:
            return fail('Invalid room token', 403)
        try:
            x = min(1.0, max(0.0, float(data.get('x', 0))))
            y = min(1.0, max(0.0, float(data.get('y', 0))))
            drag_square = data.get('drag_square')
            drag_square = int(drag_square) if drag_square is not None else None
            if drag_square is not None and not 0 <= drag_square < 64:
                return fail('Invalid dragged square')
        except (TypeError, ValueError):
            return fail('Invalid pointer position')
        visible = bool(data.get('visible'))
        now = time.time()
        connection.execute('''INSERT INTO presence(code,color,x,y,drag_square,visible,updated)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(code,color) DO UPDATE SET
            x=excluded.x,y=excluded.y,drag_square=excluded.drag_square,
            visible=excluded.visible,updated=excluded.updated''',
            (code.upper(), color, x, y, drag_square, int(visible), now))
        connection.execute('UPDATE rooms SET touched=? WHERE code=?', (now, code.upper()))
    return jsonify(ok=True)


@app.post('/api/rooms/<code>/moves')
def submit_move(code):
    data = request.get_json(silent=True) or {}
    token = str(data.get('token', ''))
    uci = str(data.get('uci', ''))
    connection = db()
    with connection:
        room, color = room_for_token(connection, code, token)
        if room is None:
            return fail('Room not found', 404)
        if color is None:
            return fail('Invalid room token', 403)
        if room['status'] != 'playing':
            return fail('Opponent has not joined yet', 409)
        board = chess.Board(room['fen'])
        expected = 'white' if board.turn == chess.WHITE else 'black'
        if color != expected:
            return fail('Wait for your opponent to move', 409)
        try:
            move = chess.Move.from_uci(uci)
        except ValueError:
            return fail('Invalid move')
        if move not in board.legal_moves:
            return fail('Illegal move')
        board.push(move)
        now = time.time()
        cursor = connection.execute('INSERT INTO events(code,kind,sender,payload,created) VALUES(?,?,?,?,?)',
                                    (code.upper(), 'move', color, json.dumps({'uci': uci}), now))
        room_status = 'finished' if board.is_game_over() else 'playing'
        connection.execute('UPDATE rooms SET fen=?,status=?,touched=? WHERE code=?',
                           (board.fen(), room_status, now, code.upper()))
        connection.execute('UPDATE presence SET visible=0,drag_square=NULL,updated=? WHERE code=? AND color=?',
                           (now, code.upper(), color))
    return jsonify(ok=True, seq=cursor.lastrowid, fen=board.fen(), status=room_status)


@app.post('/api/rooms/<code>/start')
def start_room(code):
    data = request.get_json(silent=True) or {}
    connection = db()
    with connection:
        room, color = room_for_token(connection, code, str(data.get('token', '')))
        if room is None:
            return fail('Room not found', 404)
        if color != 'white':
            return fail('Only the room owner can start the match', 403)
        if room['status'] != 'ready' or not room['guest_token']:
            return fail('Wait for an opponent to join', 409)
        now = time.time()
        connection.execute("UPDATE rooms SET status='playing',touched=? WHERE code=? AND status='ready'",
                           (now, code.upper()))
        connection.execute('INSERT INTO events(code,kind,sender,payload,created) VALUES(?,?,?,?,?)',
                           (code.upper(), 'started', 'white', '{}', now))
    return jsonify(ok=True, status='playing', opponent=room['guest_name'],
                   opponent_country=room['guest_country'],
                   opponent_device=room['guest_device'])


@app.post('/api/rooms/<code>/leave')
def leave_room(code):
    data = request.get_json(silent=True) or {}
    connection = db()
    with connection:
        room, color = room_for_token(connection, code, str(data.get('token', '')))
        if room is None:
            return jsonify(ok=True)
        if color is None:
            return fail('Invalid room token', 403)
        if color == 'white':
            connection.execute('DELETE FROM events WHERE code=?', (code.upper(),))
            connection.execute('DELETE FROM presence WHERE code=?', (code.upper(),))
            connection.execute('DELETE FROM rooms WHERE code=?', (code.upper(),))
        else:
            connection.execute("UPDATE rooms SET status='waiting',guest_name=NULL,guest_country=NULL,guest_token=NULL,guest_device='mobile',touched=? WHERE code=?",
                               (time.time(), code.upper()))
            connection.execute('DELETE FROM presence WHERE code=? AND color=?', (code.upper(), color))
            connection.execute('INSERT INTO events(code,kind,sender,payload,created) VALUES(?,?,?,?,?)',
                               (code.upper(), 'left', 'black', '{}', time.time()))
    return jsonify(ok=True)


@app.post('/api/rooms/<code>/resign')
def resign_room(code):
    data = request.get_json(silent=True) or {}
    token = str(data.get('token', ''))
    connection = db()
    with connection:
        room, color = room_for_token(connection, code, token)
        if room is None:
            return jsonify(ok=True)
        if color is None:
            return fail('Invalid room token', 403)
        connection.execute('INSERT INTO events(code,kind,sender,payload,created) VALUES(?,?,?,?,?)',
                           (code.upper(), 'resigned', color, '{}', time.time()))
        connection.execute("UPDATE rooms SET status='finished',touched=? WHERE code=?",
                           (time.time(), code.upper()))
    return jsonify(ok=True)


@app.errorhandler(413)
def too_large(_error):
    return fail('Request too large', 413)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '5000')))
