# Pixel Chess multiplayer server

Standalone Flask WSGI application for PythonAnywhere. It keeps public/private room
metadata and ordered chess move events in SQLite. The server validates every UCI move
against the current position before relaying it. Clients poll room state over HTTPS
while playing and send throttled cursor/drag presence updates. This is server-relayed
HTTP multiplayer, not direct P2P or a WebSocket connection.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Set `PIXEL_CHESS_DB` to a writable persistent path if the app directory is read-only.
For local development, `http://127.0.0.1:5000` is the API base URL.

## PythonAnywhere deploy

1. Create a PythonAnywhere Flask web app and upload this directory as a separate project.
2. Install `multiplayer_server/requirements.txt` in that web app's virtualenv.
3. In the generated WSGI file, use a project path and import like this (replace
   `YOUR_USERNAME` with your account name):

   ```python
   import os
   import sys

   project = '/home/YOUR_USERNAME/multiplayer_server'
   sys.path.insert(0, project)
   os.environ['PIXEL_CHESS_DB'] = '/home/YOUR_USERNAME/.pixel-chess/rooms.sqlite3'
   from app import app as application
   ```

   Do not call `app.run()` under WSGI.
4. Set `PIXEL_CHESS_DB` in the WSGI environment to a persistent writable path, e.g.
   `/home/YOUR_USERNAME/.pixel-chess/rooms.sqlite3`, and create its parent directory.
5. Reload the web app and verify `/api/health` returns `{"ok":true,...}`.
6. Configure the app's Multiplayer → Server URL setting with the HTTPS PythonAnywhere URL.

The current client uses short HTTP polling while a game is active. PythonAnywhere's
Flask-SocketIO/ASGI hosting is still documented as experimental and free-plan pricing
is not guaranteed, so the room protocol stays compatible with a regular Flask WSGI app.
When you upload a newer `app.py`, its first database request adds the device fields and
creates the cursor-presence table for existing room databases.

The mobile client detects its country by calling ipapi.co directly, then includes the
two-letter country code with profile and room requests. This avoids relying on
PythonAnywhere outbound access for geolocation. IP location can still be unknown or
imprecise with VPNs, carrier networks, and provider limits; the UI shows a blue globe
when the lookup is unavailable. The server treats the country as display metadata.
